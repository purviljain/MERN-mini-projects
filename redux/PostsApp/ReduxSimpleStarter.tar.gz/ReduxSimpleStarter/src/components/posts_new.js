import React, { Component } from 'react';
import { reduxForm } from 'redux-form';

class PostsNew extends Component {
    render() {
        // const { handleSubmit } = this.props; //Identical to:const handleSubmit = this.props.handleSubmit;
        return (
            <div>
                {/* <form>
                    <h3>Create a new post</h3>
                    <div className="form-group">
                        <label>Title</label>
                        <input type="text" className="form-control" />
                    </div>

                    <div className="form-group">
                        <label>Categories</label>
                        <input type="text" className="form-control" />
                    </div>

                    <div className="form-group">
                        <label>Content</label>
                        <textarea className="form-control" />
                    </div>

                    <button type="submit" className="btn btn-primary">Submit</button>
                </form> */}
                create
            </div>
        );
    }
}

// export default reduxForm({
//     form: 'PostsNewForm',
//     fields: ['title', 'categories', 'content']
// })(PostsNew);
export default PostsNew;