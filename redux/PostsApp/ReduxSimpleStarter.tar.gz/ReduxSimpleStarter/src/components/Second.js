import React, { Component } from 'react';


export default class Second extends Component {
  render() {
    return (
      <div>
        Hello to the second component
      </div>
    );
  }
}
